import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-benefits',
  templateUrl: './benefits.component.html',
  styleUrls: ['./benefits.component.css']
})
export class BenefitsComponent {

  public prodId: any;
  public prodName: any;
  public prodBrand: any;
  public prodPrice: any;
  public prodDesc: any;
  public prodStocks: any;
  public prodDiscount: any;
  public prodImage:any;


  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    console.log(this.route.snapshot.paramMap.get('id')+ ' is ID');
    

    let id = this.route.snapshot.paramMap.get('id');
    this.prodId = id;

    let name = this.route.snapshot.paramMap.get('name');
    this.prodName = name;

    let description = this.route.snapshot.paramMap.get('description');
    this.prodDesc = description;

    let brand = this.route.snapshot.paramMap.get('brand');
    this.prodBrand = brand;

    let price = this.route.snapshot.paramMap.get('price');
    this.prodPrice = price;

    let stocks = this.route.snapshot.paramMap.get('stocks');
    this.prodStocks = stocks;

    let discount = this.route.snapshot.paramMap.get('discount');
    this.prodDiscount = discount;

    let image = this.route.snapshot.paramMap.get('image');
    this.prodImage = image;
  }
}
