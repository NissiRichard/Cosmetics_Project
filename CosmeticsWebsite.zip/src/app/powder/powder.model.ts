export class ProductModel {
    id: number = 0;
    name: string = '';
    price: string = '';
    brand: string = '';
    stocks: string = '';
    rating: string = '';
    image: string = '';
    description:string='';
    discount:string='';
}