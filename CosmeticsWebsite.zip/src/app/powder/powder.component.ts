import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApiserviceService } from '../services/apiservice.service'
import { ProductModel } from './powder.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-powder',
  templateUrl: './powder.component.html',
  styleUrls: ['./powder.component.css']
})
export class PowderComponent {

  formValue !: FormGroup;
  productModelObj: ProductModel = new ProductModel();
  productData: any;
  showAdd!: boolean;
  showUpdate!: boolean;

  constructor(private formBuilder: FormBuilder,
    private api: ApiserviceService,
    private router: Router) {
  }

  ngOnInit() {
    this.formValue = this.formBuilder.group({
      name: [''],
      price: [''],
      brand: [''],
      description:[''],
      stocks: [''],
      rating: [''],
      image:[''],
      discount:['']
    })
    this.getAllProducts();
  }
  clickAddProduct() {
    this.formValue.reset();
    this.showAdd = true;
    this.showUpdate = false;
  }

  postProductDetails() {
    this.productModelObj.name = this.formValue.value.name;
    this.productModelObj.price = this.formValue.value.price;
    this.productModelObj.brand = this.formValue.value.brand;
    this.productModelObj.stocks = this.formValue.value.stocks;
    this.productModelObj.rating = this.formValue.value.rating;
    this.productModelObj.image = this.formValue.value.image;
    this.productModelObj.description = this.formValue.value.description;
    this.productModelObj.discount = this.formValue.value.discount;

    this.api.postProduct(this.productModelObj).subscribe(
      res => {
        console.log(res);
        alert("Product Added Successfully!!!");
        this.getAllProducts();
        let close = document.getElementById("cancel");
        close?.click();
        this.formValue.reset();

      },
      err => {
        alert("Something went wrong!!!");
      }
    )
  }

  getAllProducts() {
    this.api.getAllProducts().subscribe(
      res => {
        this.productData = res;
      }
    )
  }

  deleteProduct(product: any) {
    this.api.deleteProduct(product.id).subscribe(
      res => {
        alert("Product deleted");
        this.getAllProducts();
      }
    )
  }

  editProduct(data: any) {
    this.productModelObj.id = data.id;
    this.showAdd = false;
    this.showUpdate = true;
    this.formValue.controls['name'].setValue(data.name);
    this.formValue.controls['price'].setValue(data.price);
    this.formValue.controls['brand'].setValue(data.brand);
    this.formValue.controls['stocks'].setValue(data.stocks);
    this.formValue.controls['rating'].setValue(data.rating);
    this.formValue.controls['image'].setValue(data.image);
    this.formValue.controls['description'].setValue(data.description);
    this.formValue.controls['discount'].setValue(data.discount);

  }

  updateProductDetails() {
    this.productModelObj.name = this.formValue.value.name;
    this.productModelObj.price = this.formValue.value.price;
    this.productModelObj.brand = this.formValue.value.brand;
    this.productModelObj.stocks = this.formValue.value.stocks;
    this.productModelObj.rating = this.formValue.value.rating;
    this.productModelObj.image = this.formValue.value.image;
    this.productModelObj.description = this.formValue.value.description;
    this.productModelObj.discount = this.formValue.value.discount;



    this.api.updateProduct(this.productModelObj, this.productModelObj.id).subscribe(
      res => {
        console.log(res);
        alert("Product Updated Successfully!!!");
        this.getAllProducts();
        let close = document.getElementById("cancel");
        close?.click();
        this.formValue.reset();
      },
      err => {
        alert("Something went wrong!!!");
      }
    )
  }
  fetchBenefits(product: any) {
    console.log(product.id+''+product.description+" is value" );
    
    this.router.navigate(['/products',product.id,product.name,product.brand,product.price,product.description,product.stocks,product.discount,product.image]);
  }

}
